# Fortnite Archive Tool (`retrora-archive`)

A separate program from the launcher, for keeping the Fortnite builds you own: what a build is, a manifest to check copies
against, and packing and unpacking. Runs on Windows, macOS and Linux (`cargo build --release -p retrora-archive`); a Windows copy
is `dist/Fortnite Archive Tool.exe`.

| command | what it does |
|---|---|
| `identify <file or folder> [--json]` | Platform, container, release, version and changelist, read from the build's own binary |
| `manifest <folder> <manifest.json>` | Every file with its size, SHA-1 (what Epic's manifests use) and SHA-256 |
| `verify <folder> <manifest.json>` | A copy checked against a manifest: missing, changed, extra |
| `paks <file.pak or folder>` | The files inside Unreal paks whose index is not encrypted (formats 1 to 9: every Chapter 1 build) |
| `extract <zip, ipa or apk> <folder>` | Unpacks safely (no entry can land outside the folder). 7z and RAR: use 7-Zip |
| `pack <folder> <archive.zip>` | Packs a build with its manifest inside; paks and IoStore files stored as they are |

## Platforms

It reads builds and dumps **from** every platform:

| platform | what it recognises |
|---|---|
| Windows | a build folder (`FortniteClient-Win64-Shipping.exe`), the executable itself |
| macOS | a `.app` with `FortniteClient-Mac-Shipping`, Mach-O binaries |
| Linux | ELF binaries |
| iOS | an IPA (`Payload/*.app`), or its unpacked folder |
| Android | an APK (`lib/*/libUE4.so`), or its unpacked folder |
| Xbox | XVD/XVC packages (encrypted: named only) |
| Switch | NSP and XCI (encrypted content: named only) |
| PlayStation | PS4 PKG (encrypted: named only) |

## It never decrypts

Encrypted containers (console packages, App Store FairPlay binaries, encrypted pak indexes) are named as encrypted and left
closed. Decrypting them means breaking their copy protection, so this tool doesn't, and won't. It catalogues, checks, unpacks
and packs the copies you have, as they are.

## Downloads

`tools/build-archivers.ps1` builds it for every platform it runs on, into `dist/archive-tool/`:

| file | for |
|---|---|
| `Fortnite-Archive-Tool-windows-x64.zip` | Windows 10 and 11 |
| `Fortnite-Archive-Tool-linux-x64-steamdeck.zip` | Linux PCs and Steam Deck (desktop mode) |
| `Fortnite-Archive-Tool-linux-arm64.zip` | ARM Linux (Raspberry Pi and others) |
| `Fortnite-Archive-Tool-macos-intel.zip` / `-macos-apple-silicon.zip` | macOS. The first run needs right-click > Open, as it is not notarised |
| `Fortnite-Archive-Tool-android-arm64-termux.zip` | Android, inside the Termux app (`chmod +x retrora-archive`) |

iOS, Xbox, PlayStation and Switch cannot run a program like this. Their copies are made with the device's own features (below),
then read with the tool on a PC.

## Consoles and iOS: keeping a copy of a build you own

Every one of these uses the device's own menus. The copy you get is **encrypted and tied to your console or Apple ID**. It is a
real archive of that version and can be put back on the same device, but it does not play anywhere else. Retrora does not help
with jailbreaking or breaking these protections. What the tool does with these copies:
- `identify`: which platform and container it is.
- `manifest`: hashes every file, so you can prove later that the copy is intact.
- `verify`: checks a copy against its manifest.
- `pack`: keeps the copy in one file.

**First, on every console: turn off automatic updates.** A console replaces Fortnite with the newest version the moment it can,
and the old version is gone. Archive *before* it updates.

### iOS (iPhone, iPad)

- **Old versions you already have:** before iTunes 12.7 (2017), iTunes kept every app it synced as an `.ipa` file. On an old
  PC or Mac, look in `Music\iTunes\iTunes Media\Mobile Applications` (or `~/Music/iTunes/iTunes Media/Mobile Applications`) for
  `Fortnite *.ipa`. Copies of Fortnite from 2018 to 2020 are there if they were ever synced. They are the only practical source of
  old iOS builds, so copy them somewhere safe.
- **The version you have now:** on a Mac, Apple Configurator (free from the Mac App Store), signed in with your Apple ID, can add
  an app you own to a connected device. While it does, it keeps the downloaded `.ipa` in its cache
  (`~/Library/Group Containers/K36BKF7T3D.group.com.apple.configurator/Library/Caches/Assets/TemporaryItems/MobileApps/`); copy it
  from there before the copy finishes.
- An iPhone backup (Finder, iTunes or iCloud) does **not** contain apps, only their data.
- Then: `retrora-archive identify "Fortnite 13.40.ipa"` and `retrora-archive manifest <unpacked folder> fortnite-13.40-ios.json`.
  The App Store binary inside is FairPlay-encrypted; the tool says so and leaves it closed.

### Xbox (One, Series X|S)

1. Plug in a USB 3 drive. Under **Settings > System > Storage devices**, format it for games. This erases the drive.
2. **My games & apps > Fortnite > Manage game and add-ons > Move or copy**, then **Copy** to the USB drive.
3. Keep that drive as the archive. It can be copied back to an Xbox the same way.
- Turn off **Settings > System > Updates > Keep my games & apps up to date** first.
- Windows does not open a drive formatted by an Xbox. Keep the drive whole, or make a disk image of it with a disk-imaging tool.
  The tool names Xbox packages (`.xvd`/`.xvc`) when it can see them.

### PlayStation (PS4, PS5)

- **PS5:** **Settings > Storage > USB Extended Storage**: format a USB drive. In the **Game Library**, choose Fortnite > the
  **...** button > **Move** (or copy, where offered) to it. Keep the drive.
- **PS4:** **Settings > System > Back Up and Restore > Back Up PS4** to a USB drive. This saves every installed game, Fortnite
  included, in an encrypted backup that restores to a PS4 signed in to the same account. A PS4 game on a PS5's extended storage
  can also stay on that drive.
- Turn off **Settings > System Software / Saved Data and Game/App Settings > Automatic Updates** first.
- The tool names PS4 packages (`.pkg`).

### Nintendo Switch

1. Put in a microSD card, then **System Settings > Data Management > Manage Software > Fortnite > Move Data** to the microSD
   card.
2. Turn the Switch off, put the card in a PC and copy the card's whole `Nintendo` folder somewhere safe. Its files are encrypted
   to that Switch and can be copied back to the card later.
- Turn off **System Settings > System > Auto-Update Software** first.
- The tool names Switch packages (`.nsp`/`.xci`) when it is given them.

### Android (for completeness)

Android packages are not encrypted, so this is a full copy the tool can read:
1. Turn on USB debugging (**Settings > About phone**, tap **Build number** seven times, then **Developer options > USB
   debugging**).
2. Run `adb shell pm path com.epicgames.fortnite` to list the installed package parts.
3. `adb pull` each of them.
4. `retrora-archive identify base.apk` reads the release and version.

## Checked on real builds (2026-10-30)

- 1.8.1 (`builds\1.8.1-CL-3729133`): `++Fortnite+Release-Cert-CL-3729133`, version 1.8.1, changelist 3729133, 68 pak files;
  `pakchunk0-WindowsClient.pak` is format 3 with 137,095 files listed.
- 28.01: `++Fortnite+Release-28.01-CL-30313795`; its paks are format 11 with encrypted indexes (named, not read); `.utoc`
  IoStore tables are named, not yet listed.
- `dist/Retrora.ipa`: an iOS IPA with no Fortnite release in it (it is Retrora's own app), as it should be.

Tests: `cargo test -p retrora-archive` (7).
